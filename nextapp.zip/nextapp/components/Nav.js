import React from 'react'
import Link from 'next/link';
import Image from 'next/image'
import Head from 'next/head'


export default function Nav() {
   
    return (
        <div>
           <Head>
      
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm"
            crossorigin="anonymous"></link>
      </Head>


                <div class="container">
          <div class="logo">
            <img src="monkey.jpg" alt="" width="60"/>
            </div>
          <nav>
            <ul>
            <li> <Link  href='/'>  SHOP  </Link> </li>
            <li>RECIPES</li>
            <li>LEARN</li>
            <li> <Link href='/about'> ABOUT </Link> </li>
            <li> <Link href='/blog'> BLOG </Link> </li>
            </ul>
            </nav>
          </div>
      <hr />
        

     </div>
    )
}
