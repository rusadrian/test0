import Head from 'next/head'
// import styles from '../styles/Home.module.css'

export default function Home() {
  return (
    <div>

      <Head>
      
      <link rel="stylesheet"
       href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
         </link>
         <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      </link>
      </Head>
      

      <div className="container mt-5 mb-5">
        <div className="row">
             <div className="col-md-6 mt-5">

               <h1 className="display-4"> Whole-Grain Banana Bread</h1>
               <p className="p1 mt-5">
               Lorem Ipsum has been the industry's standard dummy text ever since the 
               1500s, when an unknown printer took a galley of type and scrambled it
                to make a type specimen book. It has survived not only five centuries
                , but also the leap into electronic typesetting, remaining essentially 
                unchanged. It was popularised in the 1960s with the release of Letraset
                 sheets containing Lorem Ipsum passages, and more recently with desktop
                  publishing software like Aldus PageMaker including versions of Lorem Ipsum
               </p>


               

               <div className="d-flex flex-row bd-highlight mb-3">
               
                <div className="p-2 bd-highlight">
                <p> 10 mins | </p>
                 </div>

                 <div className="p-2 bd-highlight">
                  <p>1 hr to 1 hr 15 mins | </p> 
                  </div>

                  <div className="p-2 bd-highlight">
                  <p>1 hr 10 mins | </p>
                   </div>
            </div>

            <hr/>

            <div className="d-flex flex-row bd-highlight mb-3">
               
               <div className="p-2 bd-highlight">
               <p> 1 loa,12 generous serving | </p>
                </div>

                <div className="p-2 bd-highlight">
                <button class="btn btn-info"><i class="fa fa-plus"></i> SAVE RECIPE</button>
                 </div>


                 <div className="p-2 bd-highlight">
                 <button class="btn btn-info"><i class="fa fa-print"></i> PRINT</button>
                  </div>
           </div>



              
             </div>

             <div className="col-md-6">

            <img className="img-fluid" src="burger.jpeg" alt="fdsd" />
           </div>
         </div>
     </div>

     
     
      </div>
  )
}
